from django.shortcuts import render, render_to_response
from django.http import HttpResponse
from StockAnalysis.utils import StockAnalysis_UDF

# Create your views here.

def index(request):
    """App Homepage"""
    return render(request, "index.html" , {} )    
 
def submit(request):
	if request.method == "POST":
		StockName = request.POST["txtStockName"]
		Result = StockAnalysis_UDF(StockName)
		
	return render(request,"submit.html", {} )
