﻿from yahoo_finance_api2.exceptions import YahooFinanceError
from yahoo_finance_api2 import share
from bs4 import BeautifulSoup as bs
from matplotlib import pyplot as plt
import string
import os
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
#from urllib.request import Request
# Importing Yahoo Finance API modules

# StockAnalysis UDF


def StockAnalysis_UDF(stock_name):
    try:
        stock = str(stock_name)
        my_share = share.Share(stock_name)
        stock_data = None
        stock_data = my_share.get_historical(share.PERIOD_TYPE_YEAR, 1,
                                             share.FREQUENCY_TYPE_DAY, 1)
        StockData = pd.DataFrame(stock_data, columns=stock_data.keys())
        StockData = StockData[['timestamp', 'close', 'volume']]

        """ Compute rolling mean, rolling standard deviation """
        rm = StockData['close'].rolling(window=20).mean()
        rstd = StockData['close'].rolling(window=20).std()

        """ Compute upper and lower bands """
        upper_band = rm + 2*rstd
        lower_band = rm - 2*rstd

        """ Plot Bollinger Bands """
        ax = StockData["close"].plot(title="Bollinger Bands", label=stock)
        rm.plot(label='Rolling mean', ax=ax)
        upper_band.plot(label="Upper band", ax=ax)
        lower_band.plot(label="Lower band", ax=ax)

        """ Axis labels, legend and plot """
        ax.set_ylabel("Price")
        ax.legend(loc="best")
        """ Save the image """
        plt.savefig(
            "E:/LEARNING/MATERIALS/StockAnalysisApp/WebApp_Project/Project/StockAnalysis/static/StockChart_rolling_return.png")
        plt.close()

        """ Compute daily return """
        daily_return = StockData
        daily_return["close"][1:] = (
            StockData["close"][1:] / StockData["close"][:-1].values)-1
        daily_return.iloc[0, :] = 0  # Initializing value to 0
        mean = daily_return["close"].mean()
        std = daily_return["close"].std()

        """ Plot daily return """
        ax1 = daily_return['close'].plot(color='b')
        ax1.set_xlabel("Date")
        ax1.set_ylabel("Price")
        ax1.legend(loc="best")
        plt.axhline(mean, color='r', linestyle='dashed', linewidth=2)
        plt.axhline(std, color='g', linestyle='dashed', linewidth=2)
        plt.axhline(-std, color='g', linestyle='dashed', linewidth=2)
        plt.savefig(
            "E:/LEARNING/MATERIALS/StockAnalysisApp/WebApp_Project/Project/StockAnalysis/static/StockChart_daily_return.png")
        plt.close()

        """  Plot daily return histogram """
        ax2 = daily_return['close'].hist(bins=20)
        ax2.set_xlabel("Date")
        ax2.set_ylabel("Price")
        ax2.legend(loc="best")
        plt.axvline(mean, color='w', linestyle='dashed', linewidth=2)
        plt.axvline(std, color='r', linestyle='dashed', linewidth=1)
        plt.axvline(-std, color='r', linestyle='dashed', linewidth=1)
        plt.savefig(
            "E:/LEARNING/MATERIALS/StockAnalysisApp/WebApp_Project/Project/StockAnalysis/static/StockChart_daily_return_hist.png")
        plt.close()

    except YahooFinanceError as e:
        print(e.message)
