from django.apps import AppConfig


class StockAnalysisConfig(AppConfig):
    name = 'StockAnalysis'
